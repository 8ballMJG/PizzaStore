import java.util.Scanner;

public class PizzaStore{
        public static void main(String[] args){
            System.out.println(" Get Sliced ");
            //Create a scanner for input
            Scanner scanner = new Scanner (System.in);
            System.out.println(" How many pizzas are we ordering today?");
            //Insert the number of pizzas the customer ordered
            int numberofPizzas = scanner.nextInt();
            //Use a loop to ask the user for type of pizza
            for(int counter = 1; counter<= (numberofPizzas); counter++ ){
                //Ask the user what type of crust they would like
                System.out.println(" What kind of crust would you like: Thin Crust, Hand Tossed, or Cauliflower?");
                String crustType = scanner.next();

                //Ask the user what type of sauce they would like
                System.out.println(" What kind of sauce would you like: Marinara or Alfredo?");
                String sauceType = scanner.next();

                //Ask the user what type of cheese they would like
                System.out.println(" What kind of cheese would you like: Sharp Cheddar, Mozarella, Mexican, or Parmesean?");
                String cheeseType = scanner.next();

                System.out.println(" What kind of pizza would yout like: Ham, Pepperoni, Chicken, Steak or  Cheese?");
                String pizzaType = scanner.next();

                //Ask the user what kind of toppings they would like
                System.out.println(" What kind of toppings would you like: peppers, veggies, spinach, or olives? ");
                String toppingType = scanner.next();


                //Show the user what they ordered
                System.out.println("You ordered " + scanner + ":" + crustType + sauceType +
                        cheeseType + pizzaType + toppingType);
            }//End loop

            //Thank the user
            System.out.println(" Thank you for ordering with Get Sliced, your order will be ready shortly.");


        }//end main
}//end class
